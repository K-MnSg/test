-- 데이터ERD 기준 스키마 (MySQL 8.x)   실행: mysql -u root -p < schema.sql
CREATE DATABASE IF NOT EXISTS kirik DEFAULT CHARACTER SET utf8mb4;
USE kirik;

DROP TABLE IF EXISTS payment, report, rental, member_pass, pass_product, vehicle, station, member;

-- 회원
CREATE TABLE member (
  member_id INT AUTO_INCREMENT PRIMARY KEY,
  name      VARCHAR(50)  NOT NULL,
  email     VARCHAR(100) NOT NULL UNIQUE,      -- 로그인 아이디로 사용
  password  VARCHAR(255) NOT NULL,             -- 해시 저장
  phone     VARCHAR(20)
);

-- 대여소
CREATE TABLE station (
  station_id   INT AUTO_INCREMENT PRIMARY KEY,
  station_name VARCHAR(100)  NOT NULL,
  latitude     DECIMAL(10,7) NOT NULL,
  longitude    DECIMAL(10,7) NOT NULL
);

-- 이동수단  (rental_status: 대여가능 / 대여중,  station_id NULL = 대여소 밖에 있음)
CREATE TABLE vehicle (
  vehicle_id    INT AUTO_INCREMENT PRIMARY KEY,
  vehicle_type  VARCHAR(20)   NOT NULL,        -- 킥보드 / 자전거
  battery_level INT NULL,                      -- 자전거는 NULL
  latitude      DECIMAL(10,7) NOT NULL,
  longitude     DECIMAL(10,7) NOT NULL,
  rental_status VARCHAR(20)   NOT NULL DEFAULT '대여가능',
  station_id    INT NULL,
  FOREIGN KEY (station_id) REFERENCES station(station_id)
);

-- 이용권 상품  (valid_period: 유효 일수)
CREATE TABLE pass_product (
  pass_id      INT AUTO_INCREMENT PRIMARY KEY,
  pass_name    VARCHAR(50) NOT NULL,
  pass_type    VARCHAR(30) NOT NULL,           -- 일일권 / 정기권
  price        DECIMAL(10,2) NOT NULL,
  valid_period INT NOT NULL
);

-- 회원이용권  (pass_status: 사용가능 / 만료)
CREATE TABLE member_pass (
  member_pass_id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_date  DATETIME NOT NULL,
  start_date     DATETIME NOT NULL,
  expire_date    DATETIME NOT NULL,
  pass_status    VARCHAR(20) NOT NULL,
  member_id      INT NOT NULL,
  pass_id        INT NOT NULL,
  FOREIGN KEY (member_id) REFERENCES member(member_id),
  FOREIGN KEY (pass_id)   REFERENCES pass_product(pass_id)
);

-- 대여  (return_time NULL = 이용 중)
-- ERD에는 rental_fee 가 DECIMAL(10,7) 이지만 그러면 1,000원 이상을 저장할 수 없어 DECIMAL(10,2) 로 두었음
CREATE TABLE rental (
  rental_id        INT AUTO_INCREMENT PRIMARY KEY,
  rental_time      DATETIME NOT NULL,
  return_time      DATETIME NULL,
  rental_latitude  DECIMAL(10,7) NOT NULL,
  rental_longitude DECIMAL(10,7) NOT NULL,
  return_latitude  DECIMAL(10,7) NULL,
  return_longitude DECIMAL(10,7) NULL,
  distance         DECIMAL(10,7) NOT NULL DEFAULT 0,   -- km
  rental_fee       DECIMAL(10,2) NOT NULL DEFAULT 0,
  member_id        INT NOT NULL,
  vehicle_id       INT NOT NULL,
  FOREIGN KEY (member_id)  REFERENCES member(member_id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id),
  INDEX idx_rental_active (member_id, return_time)
);

-- 신고  (report_type: 고장 / 방치,  process_status: 접수 / 처리중 / 처리완료)
CREATE TABLE report (
  report_id      INT AUTO_INCREMENT PRIMARY KEY,
  report_type    VARCHAR(30)  NOT NULL,
  report_content VARCHAR(500) NOT NULL,
  report_date    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  process_status VARCHAR(20)  NOT NULL DEFAULT '접수',
  member_id      INT NOT NULL,
  vehicle_id     INT NOT NULL,
  FOREIGN KEY (member_id)  REFERENCES member(member_id),
  FOREIGN KEY (vehicle_id) REFERENCES vehicle(vehicle_id)
);

-- 결제  (payment_type: 이용권 종류 그대로 저장)
CREATE TABLE payment (
  payment_id     INT AUTO_INCREMENT PRIMARY KEY,
  payment_type   VARCHAR(20)   NOT NULL,
  payment_amount DECIMAL(10,2) NOT NULL,
  payment_method VARCHAR(30)   NOT NULL,
  payment_date   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  member_id      INT NOT NULL,
  FOREIGN KEY (member_id) REFERENCES member(member_id)
);

-- ================= 샘플 데이터 =================
-- 데모 계정: demo@kirik.com / demo1234
INSERT INTO member (name,email,password,phone) VALUES
 ('김민성','demo@kirik.com','scrypt:32768:8:1$rzX1n28OMa4VGPZb$888818aeec9fafc3f6774129e8c16fb36a939c39e74dc7009f358058c8f6a5ccdb75226e7d4cb2e6131de61162fcaef2db0a14643c14c3d01de3196ec7cf163d','010-1234-5678');

INSERT INTO station (station_name,latitude,longitude) VALUES
 ('양주역 1번 출구',37.7856000,127.0462000),
 ('옥정호수공원',37.7861000,127.0452000),
 ('양주시청',37.7841000,127.0473000),
 ('회천중앙공원',37.7830000,127.0430000);

INSERT INTO vehicle (vehicle_id,vehicle_type,battery_level,latitude,longitude,rental_status,station_id) VALUES
 (1001,'킥보드',82,37.7857000,127.0462000,'대여가능',1),
 (1002,'킥보드',18,37.7851000,127.0461000,'대여가능',NULL),
 (1003,'자전거',NULL,37.7861000,127.0452000,'대여가능',2),
 (1004,'킥보드',64,37.7847000,127.0451000,'대여가능',NULL),
 (1005,'킥보드',91,37.7841000,127.0473000,'대여가능',3),
 (1006,'자전거',NULL,37.7856000,127.0451000,'대여중',NULL),
 (1007,'킥보드',55,37.7863000,127.0468000,'대여가능',NULL),
 (1008,'킥보드',77,37.7830000,127.0430000,'대여가능',4),
 (1009,'자전거',NULL,37.7830000,127.0430000,'대여가능',4);

INSERT INTO pass_product (pass_name,pass_type,price,valid_period) VALUES
 ('일일권 (24시간)','일일권',2000,1),
 ('30일 정기권','정기권',19000,30);

-- 만료된 이용권 1건 + 결제
INSERT INTO member_pass (purchase_date,start_date,expire_date,pass_status,member_id,pass_id) VALUES
 (DATE_SUB(NOW(), INTERVAL 20 DAY), DATE_SUB(NOW(), INTERVAL 20 DAY), DATE_SUB(NOW(), INTERVAL 19 DAY), '만료', 1, 1);
INSERT INTO payment (payment_type,payment_amount,payment_method,payment_date,member_id) VALUES
 ('일일권',2000,'카카오페이',DATE_SUB(NOW(), INTERVAL 20 DAY),1);

-- 과거 대여 기록 2건
INSERT INTO rental (rental_time,return_time,rental_latitude,rental_longitude,return_latitude,return_longitude,distance,rental_fee,member_id,vehicle_id) VALUES
 (DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_ADD(DATE_SUB(NOW(), INTERVAL 2 DAY), INTERVAL 14 MINUTE),37.7856000,127.0462000,37.7841000,127.0473000,0.2100000,3100,1,1005),
 (DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_SUB(NOW(), INTERVAL 5 DAY), INTERVAL 32 MINUTE),37.7861000,127.0452000,37.7830000,127.0430000,0.3900000,5800,1,1003);

-- 신고 2건: 1004 고장(처리중), 1002 방치(접수)
INSERT INTO report (report_type,report_content,report_date,process_status,member_id,vehicle_id) VALUES
 ('고장','브레이크가 뻑뻑함',DATE_SUB(NOW(), INTERVAL 1 DAY),'처리중',1,1004),
 ('방치','횡단보도 앞에 쓰러져 있음',DATE_SUB(NOW(), INTERVAL 3 HOUR),'접수',1,1002);
