import pymysql
from flask import g
import config


def get_db():
    if "db" not in g:
        g.db = pymysql.connect(cursorclass=pymysql.cursors.DictCursor,
                               autocommit=False, **config.DB)
    return g.db


def close_db(_=None):
    db = g.pop("db", None)
    if db:
        db.close()          # commit 하지 않은 변경은 롤백됨


def query(sql, args=None, one=False):
    with get_db().cursor() as cur:
        cur.execute(sql, args or ())
        rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


def execute(sql, args=None):
    with get_db().cursor() as cur:
        cur.execute(sql, args or ())
        return cur.lastrowid


def commit():
    get_db().commit()
