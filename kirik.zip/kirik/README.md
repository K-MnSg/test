# 끼릭 - 사용자 맞춤형 공유 킥보드/자전거 대여 시스템

데이터베이스설계(A) 2조 프로젝트. Python · Flask · MySQL · HTML/CSS/JavaScript · GitHub

## 구조
```
app.py            Flask 서버 (페이지 + JSON API, 추천 로직)
config.py         DB 접속 정보, 요금 정책, 기준 위치
db.py             PyMySQL 연결/쿼리 헬퍼
schema.sql        데이터ERD 기준 테이블 8개 + 샘플 데이터
templates/        index.html(앱 화면), login.html, register.html
static/           style.css, app.js
```

## 실행
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

mysql -u root -p < schema.sql     # DB 생성 + 샘플 데이터

export DB_PASSWORD=내MySQL비밀번호   # Windows: set DB_PASSWORD=...
python app.py                     # http://127.0.0.1:5000
```
데모 계정: `demo@kirik.com` / `demo1234` (회원가입도 가능) DB 접속 정보는 환경변수(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)로 바꿀 수 있습니다.

## API 요약
| 기능 | 엔드포인트 | 사용 테이블 |
|---|---|---|
| 회원 | POST /api/register, /api/login, /api/logout · GET/PUT /api/me | MEMBER |
| 이동수단·추천 | GET /api/vehicles, /api/stations | VEHICLE, STATION, REPORT |
| 대여·반납 | POST /api/rentals, /api/rentals/return · GET /api/rentals, /api/rentals/active | RENTAL, VEHICLE, MEMBER_PASS |
| 이용권·결제 | GET /api/passes, /api/member-passes, /api/payments · POST /api/passes/buy | PASS_PRODUCT, MEMBER_PASS, PAYMENT |
| 신고 | GET/POST /api/reports | REPORT |

## 추천 로직
별도 테이블 없이 조회 시 계산합니다. 대여 가능 + 미처리 고장 신고 없음 + 배터리 20% 이상인 이동수단만 대상으로
거리 50% + 배터리 40% + 미처리 신고 없음 10% 점수로 정렬합니다.

## GitHub
```bash
git init && git add . && git commit -m "init: 끼릭 프로젝트"
git branch -M main
git remote add origin <저장소 URL> && git push -u origin main
```
