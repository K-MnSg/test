import math
import re
from datetime import date, datetime
from decimal import Decimal
from functools import wraps

from flask import Flask, jsonify, redirect, render_template, request, session
from flask.json.provider import DefaultJSONProvider
from werkzeug.security import check_password_hash, generate_password_hash

import config
from db import close_db, commit, execute, query


class JSONProvider(DefaultJSONProvider):
    """DATETIME / DECIMAL 을 JSON 으로 변환"""

    @staticmethod
    def default(o):
        if isinstance(o, datetime):
            return o.strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(o, date):
            return o.strftime("%Y-%m-%d")
        if isinstance(o, Decimal):
            return float(o)
        return DefaultJSONProvider.default(o)


RE_EMAIL = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]{2,}$")
RE_PHONE = re.compile(r"^01[016789]-\d{3,4}-\d{4}$")

app = Flask(__name__)
app.secret_key = config.SECRET_KEY
app.json = JSONProvider(app)
app.teardown_appcontext(close_db)


def err(msg, code=400):
    return jsonify(error=msg), code


def api_login(f):
    @wraps(f)
    def wrapper(*a, **k):
        if "member_id" not in session:
            return err("로그인이 필요해요", 401)
        return f(*a, **k)
    return wrapper


def pos():
    try:
        return float(request.args["lat"]), float(request.args["lng"])
    except (KeyError, ValueError):
        return config.DEFAULT_LAT, config.DEFAULT_LNG


def label(vehicle_type, vehicle_id):
    return f"{'K' if vehicle_type == '킥보드' else 'B'}-{vehicle_id}"


# 미처리 고장 신고 (이동수단이 고장인지는 REPORT 테이블로 판단)
BROKEN = ("EXISTS (SELECT 1 FROM report r WHERE r.vehicle_id = v.vehicle_id "
          "AND r.report_type = '고장' AND r.process_status <> '처리완료')")


# ---------------------------------------------------------------- 페이지
@app.get("/")
def index():
    if "member_id" not in session:
        return redirect("/login")
    return render_template("index.html", lat=config.DEFAULT_LAT, lng=config.DEFAULT_LNG)


@app.get("/login")
def login_page():
    return render_template("login.html")


@app.get("/register")
def register_page():
    return render_template("register.html")


# ---------------------------------------------------------------- 회원 (MEMBER)
@app.post("/api/register")
def register():
    d = request.get_json(force=True)
    name, email, phone = (str(d.get(k, "")).strip() for k in ("name", "email", "phone"))
    pw = str(d.get("password", ""))
    if not (name and email and pw and phone):
        return err("이름, 이메일, 비밀번호, 연락처를 모두 입력해 주세요")
    if not RE_EMAIL.match(email):
        return err("이메일 형식이 아니에요")
    if not RE_PHONE.match(phone):
        return err("연락처 형식이 아니에요. 예: 010-1234-5678")
    if pw != d.get("password_confirm"):
        return err("비밀번호가 일치하지 않아요")
    if query("SELECT 1 FROM member WHERE email=%s", (email,), one=True):
        return err("이미 가입된 이메일이에요", 409)
    execute("INSERT INTO member(name,email,password,phone) VALUES(%s,%s,%s,%s)",
            (name, email, generate_password_hash(pw), phone))
    commit()
    return jsonify(ok=True)


@app.post("/api/login")
def login():
    d = request.get_json(force=True)
    m = query("SELECT member_id, password FROM member WHERE email=%s", (d.get("email", "").strip(),), one=True)
    if not m or not check_password_hash(m["password"], d.get("password", "")):
        return err("이메일 또는 비밀번호가 맞지 않아요", 401)
    session["member_id"] = m["member_id"]
    return jsonify(ok=True)


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


# ---------------------------------------------------------------- 이용권 (PASS_PRODUCT / MEMBER_PASS)
def refresh_passes(mid):
    """유효기간이 지난 회원이용권의 pass_status 를 '만료'로 갱신"""
    execute("UPDATE member_pass SET pass_status='만료' "
            "WHERE member_id=%s AND pass_status<>'만료' AND expire_date<=NOW()", (mid,))
    commit()


def active_pass(mid):
    refresh_passes(mid)
    return query(
        """SELECT mp.member_pass_id, p.pass_name, mp.expire_date
           FROM member_pass mp JOIN pass_product p ON p.pass_id = mp.pass_id
           WHERE mp.member_id=%s AND mp.pass_status='사용가능'
             AND mp.start_date <= NOW() AND mp.expire_date > NOW()
           ORDER BY mp.expire_date DESC LIMIT 1""", (mid,), one=True)


@app.route("/api/me", methods=["GET", "PUT"])
@api_login
def me():
    mid = session["member_id"]
    if request.method == "PUT":
        d = request.get_json(force=True)
        name, email = str(d.get("name", "")).strip(), str(d.get("email", "")).strip()
        phone = str(d.get("phone", "")).strip()
        if not name or not RE_EMAIL.match(email):
            return err("이름과 이메일을 올바르게 입력해 주세요")
        if phone and not RE_PHONE.match(phone):
            return err("연락처 형식이 아니에요. 예: 010-1234-5678")
        if query("SELECT 1 FROM member WHERE email=%s AND member_id<>%s", (email, mid), one=True):
            return err("이미 사용 중인 이메일이에요", 409)
        execute("UPDATE member SET name=%s, email=%s, phone=%s WHERE member_id=%s",
                (name, email, phone or None, mid))
        commit()
    m = query("SELECT member_id, name, email, phone FROM member WHERE member_id=%s", (mid,), one=True)
    m["active_pass"] = active_pass(mid)
    return jsonify(m)


@app.get("/api/passes")
@api_login
def passes():
    return jsonify(query("SELECT pass_id, pass_name, pass_type, price, valid_period FROM pass_product"))


@app.get("/api/member-passes")
@api_login
def member_passes():
    refresh_passes(session["member_id"])
    return jsonify(query(
        """SELECT mp.member_pass_id, p.pass_name, mp.purchase_date, mp.expire_date, mp.pass_status
           FROM member_pass mp JOIN pass_product p ON p.pass_id = mp.pass_id
           WHERE mp.member_id=%s ORDER BY mp.purchase_date DESC, mp.member_pass_id DESC""",
        (session["member_id"],)))


@app.post("/api/passes/buy")
@api_login
def buy_pass():
    mid = session["member_id"]
    d = request.get_json(force=True)
    p = query("SELECT * FROM pass_product WHERE pass_id=%s", (d.get("pass_id"),), one=True)
    if not p:
        return err("존재하지 않는 이용권이에요", 404)
    execute("""INSERT INTO member_pass(purchase_date,start_date,expire_date,pass_status,member_id,pass_id)
               VALUES(NOW(), NOW(), DATE_ADD(NOW(), INTERVAL %s DAY), '사용가능', %s, %s)""",
            (p["valid_period"], mid, p["pass_id"]))
    execute("INSERT INTO payment(payment_type,payment_amount,payment_method,payment_date,member_id) "
            "VALUES(%s,%s,%s,NOW(),%s)", (p["pass_type"], p["price"], d.get("method", "신용/체크카드"), mid))
    commit()
    return jsonify(ok=True)


@app.get("/api/payments")
@api_login
def payments():
    return jsonify(query(
        """SELECT payment_id, DATE(payment_date) AS date, payment_type, payment_amount, payment_method
           FROM payment WHERE member_id=%s ORDER BY payment_date DESC, payment_id DESC""",
        (session["member_id"],)))


# ---------------------------------------------------------------- 이동수단 조회 + 추천 (VEHICLE / STATION)
def score(v):
    """추천 점수: 거리 50% + 배터리 40% + 미처리 신고 없음 10%. 이용 불가면 -1."""
    if v["rental_status"] != "대여가능":
        return -1, "이미 대여 중이라 제외"
    if v["broken"]:
        return -1, "고장 신고가 접수되어 제외"
    b, dist = v["battery_level"], float(v["dist_m"])
    if b is not None and b < 20:
        return -1, f"배터리 {b}%로 부족해 제외"
    d = max(0.0, 1 - dist / 300)
    bat = 0.8 if b is None else b / 100
    clean = 0 if v["open_reports"] else 0.1
    reason = f"{int(dist)}m 거리 · " + ("정비 상태 양호" if b is None else f"배터리 {b}%")
    if v["open_reports"]:
        reason += " · 신고 접수됨"
    return round((d * 0.5 + bat * 0.4 + clean) * 100), reason


@app.get("/api/vehicles")
@api_login
def vehicles():
    lat, lng = pos()
    rows = query(
        """SELECT v.vehicle_id, v.vehicle_type, v.battery_level, v.latitude, v.longitude,
                  v.rental_status, s.station_name,
                  ST_Distance_Sphere(POINT(v.longitude, v.latitude), POINT(%s, %s)) AS dist_m,
                  (SELECT COUNT(*) FROM report r
                    WHERE r.vehicle_id = v.vehicle_id AND r.process_status <> '처리완료') AS open_reports,
                  """ + BROKEN + """ AS broken
           FROM vehicle v LEFT JOIN station s ON s.station_id = v.station_id""", (lng, lat))
    for v in rows:
        v["label"] = label(v["vehicle_type"], v["vehicle_id"])
        v["score"], v["reason"] = score(v)
        v["dist_m"] = int(v["dist_m"])
    rows.sort(key=lambda v: (-v["score"], v["dist_m"]))
    return jsonify(rows)


@app.get("/api/stations")
@api_login
def stations():
    lat, lng = pos()
    free = "v.rental_status='대여가능' AND NOT " + BROKEN
    rows = query(
        f"""SELECT s.station_id, s.station_name, s.latitude, s.longitude,
                   ST_Distance_Sphere(POINT(s.longitude, s.latitude), POINT(%s, %s)) AS dist_m,
                   COUNT(CASE WHEN v.vehicle_type='킥보드' AND {free} THEN 1 END) AS kick,
                   COUNT(CASE WHEN v.vehicle_type='자전거' AND {free} THEN 1 END) AS bike
            FROM station s LEFT JOIN vehicle v ON v.station_id = s.station_id
            GROUP BY s.station_id, s.station_name, s.latitude, s.longitude
            ORDER BY dist_m""", (lng, lat))
    for s in rows:
        s["dist_m"] = int(s["dist_m"])
    return jsonify(rows)


# ---------------------------------------------------------------- 대여 / 반납 (RENTAL)
ACTIVE_RENTAL_SQL = """
    SELECT r.rental_id, r.vehicle_id, v.vehicle_type, r.rental_latitude, r.rental_longitude,
           TIMESTAMPDIFF(SECOND, r.rental_time, NOW()) AS elapsed,
           EXISTS (SELECT 1 FROM member_pass mp WHERE mp.member_id = r.member_id
                   AND r.rental_time BETWEEN mp.start_date AND mp.expire_date) AS has_pass
    FROM rental r JOIN vehicle v ON v.vehicle_id = r.vehicle_id
    WHERE r.member_id=%s AND r.return_time IS NULL"""


@app.post("/api/rentals")
@api_login
def start_rental():
    mid = session["member_id"]
    vid = request.get_json(force=True).get("vehicle_id")
    if query("SELECT 1 FROM rental WHERE member_id=%s AND return_time IS NULL", (mid,), one=True):
        return err("이미 이용 중인 이동수단이 있어요", 409)
    v = query("SELECT rental_status, latitude, longitude FROM vehicle v WHERE vehicle_id=%s FOR UPDATE",
              (vid,), one=True)
    if not v or v["rental_status"] != "대여가능":
        return err("지금은 대여할 수 없는 이동수단이에요", 409)
    if query("SELECT 1 FROM report WHERE vehicle_id=%s AND report_type='고장' AND process_status<>'처리완료'",
             (vid,), one=True):
        return err("고장 신고가 접수된 이동수단이에요", 409)
    execute("""INSERT INTO rental(rental_time, rental_latitude, rental_longitude, member_id, vehicle_id)
               VALUES(NOW(), %s, %s, %s, %s)""", (v["latitude"], v["longitude"], mid, vid))
    execute("UPDATE vehicle SET rental_status='대여중', station_id=NULL WHERE vehicle_id=%s", (vid,))
    commit()
    return jsonify(ok=True)


@app.get("/api/rentals/active")
@api_login
def active_rental():
    r = query(ACTIVE_RENTAL_SQL, (session["member_id"],), one=True)
    if r:
        r["label"] = label(r["vehicle_type"], r["vehicle_id"])
        r["has_pass"] = bool(r["has_pass"])
    return jsonify(r)


@app.post("/api/rentals/return")
@api_login
def return_rental():
    d = request.get_json(force=True)
    r = query(ACTIVE_RENTAL_SQL + " FOR UPDATE", (session["member_id"],), one=True)
    if not r:
        return err("이용 중인 이동수단이 없어요", 404)
    sid = d.get("station_id")
    if sid:   # 대여소에 반납
        st = query("SELECT latitude, longitude FROM station WHERE station_id=%s", (sid,), one=True)
        if not st:
            return err("존재하지 않는 대여소예요", 404)
        lat, lng = float(st["latitude"]), float(st["longitude"])
    else:     # 현재 위치에 반납
        sid = None
        lat, lng = float(d.get("lat", config.DEFAULT_LAT)), float(d.get("lng", config.DEFAULT_LNG))
    minutes = max(1, math.ceil(r["elapsed"] / 60))
    fee = 0 if r["has_pass"] else config.BASE_FEE + config.PER_MIN_FEE * minutes
    # 이동거리(km): 대여 좌표와 반납 좌표 사이의 직선거리
    km = query("SELECT ST_Distance_Sphere(POINT(%s,%s), POINT(%s,%s)) / 1000 AS km",
               (r["rental_longitude"], r["rental_latitude"], lng, lat), one=True)["km"]
    execute("""UPDATE rental SET return_time=NOW(), return_latitude=%s, return_longitude=%s,
               distance=%s, rental_fee=%s WHERE rental_id=%s""",
            (lat, lng, round(float(km), 3), fee, r["rental_id"]))
    execute("UPDATE vehicle SET rental_status='대여가능', latitude=%s, longitude=%s, station_id=%s "
            "WHERE vehicle_id=%s", (lat, lng, sid, r["vehicle_id"]))
    commit()
    return jsonify(minutes=minutes, distance=round(float(km), 2), fee=fee)


@app.get("/api/rentals")
@api_login
def rental_history():
    rows = query(
        """SELECT r.rental_id, r.vehicle_id, v.vehicle_type, DATE(r.rental_time) AS date,
                  TIMESTAMPDIFF(MINUTE, r.rental_time, r.return_time) AS minutes, r.distance, r.rental_fee
           FROM rental r JOIN vehicle v ON v.vehicle_id = r.vehicle_id
           WHERE r.member_id=%s AND r.return_time IS NOT NULL
           ORDER BY r.rental_time DESC""", (session["member_id"],))
    for r in rows:
        r["label"] = label(r["vehicle_type"], r["vehicle_id"])
    return jsonify(rows)


# ---------------------------------------------------------------- 신고 (REPORT)
@app.route("/api/reports", methods=["GET", "POST"])
@api_login
def reports():
    mid = session["member_id"]
    if request.method == "POST":
        d = request.get_json(force=True)
        if d.get("report_type") not in ("고장", "방치") or not str(d.get("report_content", "")).strip():
            return err("신고 유형과 내용을 입력해 주세요")
        if not query("SELECT 1 FROM vehicle WHERE vehicle_id=%s", (d.get("vehicle_id"),), one=True):
            return err("존재하지 않는 이동수단이에요", 404)
        execute("""INSERT INTO report(report_type, report_content, report_date, process_status, member_id, vehicle_id)
                   VALUES(%s, %s, NOW(), '접수', %s, %s)""",
                (d["report_type"], d["report_content"].strip()[:500], mid, d["vehicle_id"]))
        commit()
        return jsonify(ok=True)
    rows = query(
        """SELECT r.report_id, r.report_type, r.report_content, r.report_date, r.process_status,
                  r.vehicle_id, v.vehicle_type
           FROM report r JOIN vehicle v ON v.vehicle_id = r.vehicle_id
           WHERE r.member_id=%s ORDER BY r.report_date DESC, r.report_id DESC""", (mid,))
    for r in rows:
        r["label"] = label(r["vehicle_type"], r["vehicle_id"])
    return jsonify(rows)


@app.get("/api/vehicle-options")
@api_login
def vehicle_options():
    rows = query("SELECT vehicle_id, vehicle_type FROM vehicle ORDER BY vehicle_id")
    return jsonify([{"vehicle_id": r["vehicle_id"], "label": label(r["vehicle_type"], r["vehicle_id"])} for r in rows])


if __name__ == "__main__":
    app.run(debug=True)
