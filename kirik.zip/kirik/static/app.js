const $ = s => document.querySelector(s);
const won = n => Number(n).toLocaleString('ko-KR') + '원';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const POS = window.DEFAULT_POS;
const S = { tab: 'home', filter: 'all', sel: null, timer: null, me: null };
const TABS = [['home', '🧭', '추천'], ['rent', '🛴', '대여'], ['pass', '🎫', '이용권'], ['hist', '🕘', '내역'], ['me', '👤', '내 정보']];

async function api(url, method = 'GET', body) {
  const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401) { location.href = '/login'; throw new Error('로그인이 필요해요'); }
  if (!r.ok) throw new Error(d.error || '요청에 실패했어요');
  return d;
}
function toast(m) { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(t._t); t._t = setTimeout(() => t.style.display = 'none', 2400); }
function modal(h) { $('#sheet').innerHTML = h; $('#modal').classList.add('on'); }
function closeM() { $('#modal').classList.remove('on'); }
$('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeM(); });
const icon = t => t === '킥보드' ? '🛴' : '🚲';
async function act(fn) { try { await fn(); } catch (e) { toast(e.message); } }

async function render() {
  clearInterval(S.timer);
  S.me = await api('/api/me');
  $('#tabs').innerHTML = TABS.map(t => `<button class="tab ${S.tab === t[0] ? 'on' : ''}" data-t="${t[0]}"><b>${t[1]}</b>${t[2]}</button>`).join('');
  document.querySelectorAll('.tab').forEach(b => b.onclick = () => { S.tab = b.dataset.t; render(); });
  const p = S.me.active_pass;
  $('#passBadge').textContent = p ? p.pass_name + ' 이용 중' : '이용권 없음';
  $('#passBadge').className = 'badge ' + (p ? 'ok' : '');
  const T = {
    home: ['지금 탈 수 있는 것', '현재 위치: 양주역 앞'], rent: ['대여·반납', ''], pass: ['이용권·결제', '이용권을 사면 대여 요금이 무료예요'],
    hist: ['이용 내역', '지난 대여 기록'], me: ['내 정보', S.me.name + '님']
  }[S.tab];
  $('#title').textContent = T[0]; $('#subtitle').textContent = T[1];
  await act(() => VIEWS[S.tab]());
  window.scrollTo(0, 0);
}

/* ------------------------------ 추천 홈 (VEHICLE, STATION) */
function xy(v) {
  const dx = (v.longitude - POS.lng) * 111320 * Math.cos(POS.lat * Math.PI / 180), dy = -(v.latitude - POS.lat) * 110540;
  return [Math.min(345, Math.max(15, 180 + dx * .5)), Math.min(215, Math.max(15, 110 + dy * .5))];
}
function vehCard(v, rec) {
  const ok = v.score >= 0, b = v.battery_level;
  const bar = b === null ? '' : `<div class="bar"><i class="${b < 20 ? 'low' : ''}" style="width:${b}%"></i></div>`;
  return `<div class="card veh ${S.sel === v.vehicle_id ? 'sel' : ''}" data-v="${v.vehicle_id}" style="${ok ? '' : 'opacity:.6'}">
    <div class="ico">${icon(v.vehicle_type)}</div>
    <div style="flex:1"><div class="row sp"><b>${v.label} <span class="sub">${v.vehicle_type}</span></b>
      ${rec ? '<span class="badge rec">추천</span>' : ok ? '<span class="badge ok">대여 가능</span>' : '<span class="badge no">이용 불가</span>'}</div>
      <div class="why">${esc(v.reason)}</div>
      <div class="row" style="margin-top:6px">${bar}<span class="sub">${esc(v.station_name || '거리에 있음')}</span></div></div>
    ${ok ? `<button class="btn" data-rent="${v.vehicle_id}">대여</button>` : ''}</div>`;
}
async function rentVehicle(id) {
  await api('/api/rentals', 'POST', { vehicle_id: Number(id) });
  toast('대여를 시작했어요'); S.tab = 'rent'; render();
}
function bindRent() {
  document.querySelectorAll('[data-rent]').forEach(b => b.onclick = e => { e.stopPropagation(); act(() => rentVehicle(b.dataset.rent)); });
}
const VIEWS = {};
VIEWS.home = async () => {
  const q = `lat=${POS.lat}&lng=${POS.lng}`;
  const [vs, st] = await Promise.all([api('/api/vehicles?' + q), api('/api/stations?' + q)]);
  const L = vs.filter(v => S.filter === 'all' || v.vehicle_type === S.filter), top = L.find(v => v.score >= 0);
  const pins = vs.map(v => {
    const [x, y] = xy(v), c = v.score < 0 ? '#9aa79f' : (top && v.vehicle_id === top.vehicle_id ? '#f2b632' : '#0f7a55');
    return `<g class="pin" tabindex="0" role="button" data-v="${v.vehicle_id}" aria-label="${v.label}"><circle cx="${x}" cy="${y}" r="${S.sel === v.vehicle_id ? 15 : 11}" fill="${c}" stroke="#fff" stroke-width="2"/><text x="${x}" y="${y + 4}" text-anchor="middle" font-size="12">${icon(v.vehicle_type)}</text></g>`;
  }).join('');
  $('#view').innerHTML = `<div class="map"><svg viewBox="0 0 360 230" preserveAspectRatio="xMidYMid slice" aria-label="주변 이동수단 지도">
    <path d="M0 110H360M180 0V230M0 190L360 30" stroke="var(--road)" stroke-width="14" fill="none"/>
    ${pins}<circle cx="180" cy="110" r="16" fill="#2563eb" opacity=".2"/><circle cx="180" cy="110" r="7" fill="#2563eb" stroke="#fff" stroke-width="3"/></svg></div>
    <div class="row" style="margin:12px 0 4px">${[['all', '전체'], ['킥보드', '킥보드'], ['자전거', '자전거']].map(f => `<button class="chip ${S.filter === f[0] ? 'on' : ''}" data-f="${f[0]}">${f[1]}</button>`).join('')}</div>
    <h2>이용하기 좋은 순서</h2>${L.map(v => vehCard(v, top && v.vehicle_id === top.vehicle_id)).join('')}
    <h2>가까운 대여소</h2>${st.map(s => `<div class="card row sp"><div><b>${esc(s.station_name)}</b><div class="sub">${s.dist_m}m</div></div><div class="sub">🛴 ${s.kick}대 · 🚲 ${s.bike}대</div></div>`).join('')}`;
  document.querySelectorAll('[data-f]').forEach(b => b.onclick = () => { S.filter = b.dataset.f; render(); });
  document.querySelectorAll('.pin').forEach(p => { p.onclick = () => { S.sel = Number(p.dataset.v); render(); }; p.onkeydown = e => { if (e.key === 'Enter') { S.sel = Number(p.dataset.v); render(); } }; });
  bindRent();
};

/* ------------------------------ 대여 / 반납 (RENTAL) */
VIEWS.rent = async () => {
  const r = await api('/api/rentals/active');
  $('#subtitle').textContent = r ? '이용 중' : '이용 중인 이동수단 없음';
  if (!r) {
    const vs = await api(`/api/vehicles?lat=${POS.lat}&lng=${POS.lng}`), top = vs.find(v => v.score >= 0);
    $('#view').innerHTML = `<div class="empty">이용 중인 이동수단이 없어요.</div>` + (top ? `<div class="card"><div class="sub">지금 가장 추천하는 이동수단</div>${vehCard(top, true)}</div>` : '');
    bindRent(); return;
  }
  const st = await api(`/api/stations?lat=${POS.lat}&lng=${POS.lng}`), t0 = Date.now() - r.elapsed * 1000, free = r.has_pass;
  $('#view').innerHTML = `<div class="card" style="text-align:center"><div class="sub">${icon(r.vehicle_type)} ${r.label} 이용 중</div><div class="timer" id="tm">00:00</div>
    <div class="stat" style="margin:12px 0"><b id="fee">${won(free ? 0 : 1000)}</b>예상 요금${free ? ' (이용권 적용)' : ''}</div>
    <label for="retSt" style="text-align:left">반납 위치</label>
    <select id="retSt"><option value="">현재 위치(거리)에 반납</option>${st.map(s => `<option value="${s.station_id}">${esc(s.station_name)} (${s.dist_m}m)</option>`).join('')}</select>
    <button class="btn full" style="margin-top:12px" id="btnReturn">반납하기</button>
    <button class="btn ghost full" style="margin-top:8px" id="btnRep">이 이동수단 신고</button></div>
    <p class="sub">기본요금 1,000원 + 분당 150원 · 이용권 보유 시 무료</p>`;
  const tick = () => {
    const s = Math.floor((Date.now() - t0) / 1000);
    $('#tm').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
    $('#fee').textContent = won(free ? 0 : 1000 + 150 * Math.max(1, Math.ceil(s / 60)));
  };
  tick(); S.timer = setInterval(tick, 1000);
  $('#btnRep').onclick = () => reportForm(r.vehicle_id);
  $('#btnReturn').onclick = () => act(async () => {
    const sid = $('#retSt').value;
    const d = await api('/api/rentals/return', 'POST', { station_id: sid ? Number(sid) : null, lat: POS.lat, lng: POS.lng });
    clearInterval(S.timer);
    modal(`<h2 style="margin-top:0">반납이 끝났어요</h2><div class="row"><div class="stat"><b>${d.minutes}분</b>이용 시간</div><div class="stat"><b>${d.distance}km</b>이동 거리</div><div class="stat"><b>${won(d.fee)}</b>요금</div></div><button class="btn full" style="margin-top:14px" id="ok">확인</button>`);
    $('#ok').onclick = () => { closeM(); S.tab = 'hist'; render(); };
  });
};

/* ------------------------------ 이용권 / 결제 (PASS_PRODUCT, MEMBER_PASS, PAYMENT) */
VIEWS.pass = async () => {
  const [ps, mps, pays] = await Promise.all([api('/api/passes'), api('/api/member-passes'), api('/api/payments')]);
  $('#view').innerHTML = `<h2>이용권 구매</h2>` + ps.map(p => `<div class="card pass row sp"><div><b>${esc(p.pass_name)}</b><div class="sub">${p.valid_period}일간 무제한 이용</div></div><button class="btn" data-buy="${p.pass_id}">${won(p.price)}</button></div>`).join('') +
    `<h2>내 이용권</h2>` + (mps.length ? mps.map(m => `<div class="card pass"><div class="row sp"><b>${esc(m.pass_name)}</b><span class="badge ${m.pass_status === '사용가능' ? 'ok' : ''}">${esc(m.pass_status)}</span></div><div class="sub">${m.purchase_date.slice(0, 10)} 구매 · ${m.expire_date.slice(0, 16)}까지</div></div>`).join('') : `<div class="empty">보유한 이용권이 없어요. 위에서 구매해 보세요.</div>`) +
    `<h2>결제 내역</h2>` + (pays.length ? pays.map(p => `<div class="card row sp"><div><b>${esc(p.payment_type)}</b><div class="sub">${p.date} · ${esc(p.payment_method)}</div></div><b>${won(p.payment_amount)}</b></div>`).join('') : '<div class="empty">결제 내역이 없어요.</div>');
  document.querySelectorAll('[data-buy]').forEach(b => b.onclick = () => {
    const p = ps.find(x => x.pass_id == b.dataset.buy);
    modal(`<h2 style="margin-top:0">${esc(p.pass_name)} 결제</h2><p class="sub">${p.valid_period}일간 무제한 이용</p><label for="pm">결제 수단</label><select id="pm"><option>신용/체크카드</option><option>카카오페이</option><option>네이버페이</option></select>
      <div class="row" style="margin-top:14px"><button class="btn ghost full" id="c1">취소</button><button class="btn full" id="c2">${won(p.price)} 결제</button></div>`);
    $('#c1').onclick = closeM;
    $('#c2').onclick = () => act(async () => { await api('/api/passes/buy', 'POST', { pass_id: p.pass_id, method: $('#pm').value }); closeM(); toast('이용권을 구매했어요'); render(); });
  });
};

/* ------------------------------ 이용 내역 (RENTAL) */
VIEWS.hist = async () => {
  const H = await api('/api/rentals'), tm = H.reduce((a, h) => a + h.minutes, 0), km = H.reduce((a, h) => a + h.distance, 0);
  $('#view').innerHTML = `<div class="row"><div class="stat"><b>${H.length}회</b>이용</div><div class="stat"><b>${tm}분</b>총 시간</div><div class="stat"><b>${km.toFixed(2)}km</b>총 거리</div></div><h2>대여 기록</h2>` +
    (H.length ? H.map(h => `<div class="card"><div class="row sp"><b>${icon(h.vehicle_type)} ${h.label}</b><b>${won(h.rental_fee)}</b></div><div class="sub">${h.date} · ${h.minutes}분 · ${h.distance.toFixed(2)}km</div></div>`).join('') : '<div class="empty">아직 이용 기록이 없어요.</div>');
};

/* ------------------------------ 내 정보 / 신고 (MEMBER, REPORT) */
VIEWS.me = async () => {
  const R = await api('/api/reports'), u = S.me;
  $('#view').innerHTML = `<div class="card"><div class="row sp"><b>${esc(u.name)}</b><button class="btn ghost" id="btnEdit">수정</button></div><div class="sub">${esc(u.email)}<br>${esc(u.phone || '-')}</div></div>
    <div class="row sp"><h2>신고 내역</h2><button class="btn" id="btnNewRep">신고하기</button></div>` +
    (R.length ? R.map(r => `<div class="card"><div class="row sp"><b>${r.label} · ${esc(r.report_type)}</b><span class="badge ${r.process_status === '처리완료' ? 'ok' : ''}">${esc(r.process_status)}</span></div><div class="sub">${esc(r.report_content)}</div><div class="sub">${r.report_date.slice(0, 16)}</div></div>`).join('') : '<div class="empty">접수한 신고가 없어요.</div>') +
    `<button class="btn ghost full" id="btnOut" style="margin-top:8px">로그아웃</button>`;
  $('#btnNewRep').onclick = () => reportForm();
  $('#btnOut').onclick = async () => { await api('/api/logout', 'POST'); location.href = '/login'; };
  $('#btnEdit').onclick = () => {
    modal(`<h2 style="margin-top:0">회원정보 수정</h2><label for="e1">이름</label><input id="e1" value="${esc(u.name)}"><label for="e2">이메일</label><input id="e2" type="email" value="${esc(u.email)}"><label for="e3">연락처</label><input id="e3" value="${esc(u.phone)}"><button class="btn full" style="margin-top:14px" id="e4">저장</button>`);
    $('#e4').onclick = () => act(async () => { await api('/api/me', 'PUT', { name: $('#e1').value, email: $('#e2').value, phone: $('#e3').value }); closeM(); toast('저장했어요'); render(); });
  };
};

async function reportForm(vid) {
  const opts = await api('/api/vehicle-options');
  modal(`<h2 style="margin-top:0">이동수단 신고</h2><label for="rv">이동수단</label><select id="rv">${opts.map(o => `<option value="${o.vehicle_id}" ${o.vehicle_id === vid ? 'selected' : ''}>${o.label}</option>`).join('')}</select>
    <label for="rk">신고 유형</label><select id="rk"><option>고장</option><option>방치</option></select><label for="rm">내용</label><textarea id="rm" rows="3" maxlength="500" placeholder="어떤 문제인지 알려주세요"></textarea>
    <div class="row" style="margin-top:14px"><button class="btn ghost full" id="r1">취소</button><button class="btn full" id="r2">신고 접수</button></div>`);
  $('#r1').onclick = closeM;
  $('#r2').onclick = () => act(async () => {
    await api('/api/reports', 'POST', { vehicle_id: Number($('#rv').value), report_type: $('#rk').value, report_content: $('#rm').value });
    closeM(); toast('신고가 접수됐어요'); S.tab = 'me'; render();
  });
}

render();
