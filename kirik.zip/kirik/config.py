import os

SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")

DB = dict(
    host=os.environ.get("DB_HOST", "localhost"),
    port=int(os.environ.get("DB_PORT", 3306)),
    user=os.environ.get("DB_USER", "root"),
    password=os.environ.get("DB_PASSWORD", ""),
    database=os.environ.get("DB_NAME", "kirik"),
    charset="utf8mb4",
)

# 데모용 기준 위치 (양주역 인근, 대략적인 좌표)
DEFAULT_LAT = 37.7853
DEFAULT_LNG = 127.0458

# 요금 정책
BASE_FEE = 1000      # 기본요금(원)
PER_MIN_FEE = 150    # 분당 요금(원)
